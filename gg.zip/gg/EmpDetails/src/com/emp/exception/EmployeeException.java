package com.emp.exception;

	public class EmployeeException extends Exception 
	{
			public EmployeeException(String message) {
				super(message);	}
	}
