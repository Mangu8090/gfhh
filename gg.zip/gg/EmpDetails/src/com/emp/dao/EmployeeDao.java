package com.emp.dao;


import com.emp.bin.Employeebean;
import com.emp.exception.EmployeeException;

public interface EmployeeDao {

	public int addEmployee(Employeebean bean) throws EmployeeException;
	public Employeebean viewEmpById(int id) throws EmployeeException;
}
