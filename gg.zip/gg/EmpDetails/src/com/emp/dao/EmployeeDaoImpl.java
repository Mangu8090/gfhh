package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.emp.bin.Employeebean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {

	
	public int addEmployee(Employeebean bean) throws EmployeeException
	{
		int id=0;
		Connection con= null;
		String cmd="insert into Employee_tbl(emp_id,emp_firstName,emp_lastName,emp_contact,dateOfJoining,email) values(?,?,?,?,SYSDATE,?)";
		
		try {
			con=DBConnection.getConnection();
			id=generateEmployeeId();
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,id);
			ps.setString(2,bean.getEmp_firstName());
			ps.setString(3, bean.getEmp_lastName());
			ps.setLong(4, bean.getEmp_contact());
			ps.setString(5, bean.getEmail());
			int n=ps.executeUpdate();
			System.out.println(n);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new EmployeeException("unable to insert");
		}
		return id;
	}
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = null;
		String str= "select seq.nextval from dual";
		try {
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return id;
	}
	
	public Employeebean viewEmpById(int id) throws EmployeeException
	{
		Connection con= null;
		Statement stmt =null;
		Employeebean bean= new Employeebean();
		
		try {
			con=DBConnection.getConnection();
			String cmd="select emp_id,emp_firstName,emp_lastName,emp_contact,dateOfJoining,email from Employee_tbl where emp_id ="+ id;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 
			if( result.next()){
				 bean.setEmp_id(result.getInt(1));
					bean.setEmp_firstName(result.getString(2));
					bean.setEmp_lastName(result.getString(3));
					bean.setEmp_contact(result.getLong(4));
					bean.setDateOfJoining(result.getDate(5));
					bean.setEmail(result.getString(6));
					}
		}
		catch (Exception e) 
		{
			throw new EmployeeException("unable to view by id");
		}
		return bean;	
	}
}

