package com.emp.service;

import com.emp.bin.Employeebean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {

	public int addEmployee(Employeebean bean) throws EmployeeException;
	public Employeebean viewEmpById(int id) throws EmployeeException;
}