package com.emp.service;


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bin.Employeebean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	
	public int addEmployee(Employeebean bean) throws EmployeeException{
		EmployeeDao obj=new EmployeeDaoImpl();
		int id=obj.addEmployee(bean);
		return id;
	}
	
	public  Employeebean viewEmpById(int id) throws EmployeeException 
	{
		Employeebean bean = new Employeebean();
		EmployeeDao employeedao=new EmployeeDaoImpl();
		bean = employeedao.viewEmpById(id);
		return bean;
	}
	public boolean validateEmployee(Employeebean bean) throws EmployeeException
	{
		 boolean validate=true;
		List<String> validationErrors = new ArrayList<String>();

		//Validating first name
		if(!(isValidName(bean.getEmp_firstName()))) {
			validationErrors.add("\n First Name Should Be In Alphabets and minimum 4 characters long and max 15 characters! \n");
		}
		// Validating last name
		if(!(isValidName(bean.getEmp_lastName()))){
			validationErrors.add("\n Last Name Should Be In Alphabets and minimum 4 characters long and max 15 characters! \n");
		}
		
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getEmp_contact()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
	}
		public boolean isValidName(String Name){
			Pattern namePattern=Pattern.compile("[A-Z][A-Za-z]{3,14}$");
			Matcher nameMatcher=namePattern.matcher(Name);
			return nameMatcher.matches();
		}
	
		public boolean isValidemail(String email){
			Pattern phonePattern=Pattern.compile("[a-z0-9/_.+-]+@[a-z]{2,6}+.[a-z]{2,4}$");
			Matcher phoneMatcher=phonePattern.matcher(email);
			return phoneMatcher.matches();
		}
		
		public boolean isValidPhoneNumber(long phoneNumber){
			Pattern phonePattern=Pattern.compile("[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(String.valueOf(phoneNumber));
			return phoneMatcher.matches();
		}
		return validate;
		/*//Validating address
		if(!(isValidAddress(bean.getAddress()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		
		//Validating Donation Amount
		if(!(isValidAmount(bean.getDonationAmount()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new DonorException(validationErrors +"");
	}

	
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateDonorId(String donorId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(donorId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}*/
}