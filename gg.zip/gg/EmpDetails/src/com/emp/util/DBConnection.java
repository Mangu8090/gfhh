package com.emp.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.emp.exception.EmployeeException;

public class DBConnection
{
	public DBConnection(){
	}
	
	public static Connection getConnection() throws EmployeeException
	{
		Connection con=null;
		Properties props = new Properties();
		
		try {
			FileReader fr = new FileReader("resources/jdbc.properties");
			props.load(fr);
			String url=props.getProperty("jdbcurl");
			String user =props.getProperty("user");
			String pass=props.getProperty("pass");
			
			con=DriverManager.getConnection(url, user, pass);
		} 
		catch (FileNotFoundException e)
		{
			throw new EmployeeException("jdbc.properties file not found");
		} 
		catch (IOException e) 
		{
			throw new EmployeeException("unable to read jdbc.properties");
		} 
		catch (SQLException e) 
		{
			throw new EmployeeException("unable to connect to database");
		}
	
		
		return con;
	}
}

