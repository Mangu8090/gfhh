package com.emp.pl;

import java.util.Scanner;

import com.emp.bin.Employeebean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImpl;

public class EMSApp {

	public static void main(String[] args) {
		int n1;
		do{
		System.out.println("1.add employee details");
		System.out.println("2.view Employee by id");
		System.out.println("3.exit");
		System.out.println("Enter choice");
		Scanner sc= new Scanner(System.in);
		
		int n= sc.nextInt();
		switch(n)
		{
		case 1:
			System.out.println("Enter employee first name");
			String name= sc.next();
			System.out.println("Enter employee last name");
			String last= sc.next();
			System.out.println("Enter employee contact");
			long phone= sc.nextLong();
			System.out.println("Enter employee email");
			String email= sc.next();
			
			Employeebean bean=new Employeebean();
			bean.setEmp_firstName(name);
			bean.setEmp_lastName(last);
			bean.setEmp_contact(phone);
			bean.setEmail(email);
			
			EmployeeService service=new EmployeeServiceImpl();
			try{
			int id=service.addEmployee(bean);
			System.out.println("id added is="+id);
			}
			catch (EmployeeException e) 
			{	
				e.printStackTrace();
			}
		  break;
		  default:
			  break;
			  
			  
		  case 2:
			  System.out.println("enter id you want to view: ");
				int id = sc.nextInt();
				EmployeeService service2 = new EmployeeServiceImpl();
				
				try {
					Employeebean bean1  =service2.viewEmpById(id);
					System.out.println("the details of id : "+id);
					System.out.println(bean1.toString());//getEmployeeId()+" "+bean1.getEmployeeName()+" "+bean1.getEmployeesalary());
				}
				catch (EmployeeException e) 
				{
					e.printStackTrace();
				}
				break;
		}
		System.out.println("Do you want to continue\n1.yes2.no");
		Scanner sc1= new Scanner(System.in);
		n1=sc1.nextInt();
		}
		while(n1>0 && n1<2);
		}
	}


