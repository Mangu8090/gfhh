package com.ems.dao.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class TestCon {
 
	@Ignore
	@Test
	public void testconnection() throws EmployeeException {
		 Connection con = DBConnection.getConnection();
		 assertNotNull(con);
	}
     
     @Test
     (expected=EmployeeException.class) // testing for exception
 	public void testconnectionfail() throws EmployeeException {
 		 Connection con = DBConnection.getConnection();
 	}
     
     
     
}
