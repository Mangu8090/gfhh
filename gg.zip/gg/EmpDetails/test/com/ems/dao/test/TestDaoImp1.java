package com.ems.dao.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImp1;
import com.emp.exception.EmployeeException;

public class TestDaoImp1 {

	static EmployeeDaoImpl employeeDao;
	static Employeebean bean;
	
	@BeforeClass
	public static void beforeClass()
	{
		employeeDao=new EmployeeDaoImpl();
		bean=new Employeebean();
		
	}
	
	@Test
	public void testAddEmployee() throws EmployeeException
	{
		bean.setEname("vijay");
		bean.setEsal(98000);
		int id=employeeDao.addEmployee(bean);
		assertTrue(id>0);
		
	}
}
