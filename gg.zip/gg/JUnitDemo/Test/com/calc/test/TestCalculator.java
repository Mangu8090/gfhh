package com.calc.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestCalculator {
	
	@BeforeClass // call only once
	public static void beforeClass()
	{
		System.out.println("before class");
	}
	@AfterClass
	public static void afterClass()
	{
		System.out.println("after class");
	}
	@Before
	public void beforeTest()
	{
		System.out.println("before");
	}
	@Ignore
	@Test // without this test will not run
	public void m1() {
System.out.println("m1 called");
	}
	@Test // without this test will not run
	public void m2() {
System.out.println("m2 called");
	}
	@After
	public void AfterTest()
	{
		System.out.println("after");
	}
}
