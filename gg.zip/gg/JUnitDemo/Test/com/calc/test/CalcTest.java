package com.calc.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.calc.Calculator;

public class CalcTest {
	static Calculator obj;
	
	@BeforeClass // call only once
	public static void beforeClass()
	{
		 obj=new Calculator();
	}
	
	@Before
	public void beforeTest()
	{
		obj=new Calculator();
		
		System.out.println("before");
	}

	@Test
	public void testAdd() {
		
		int n = obj.add(10, 20);

		assertEquals(30, n);
	}

	@Test
	public void testSub() {
		
		int n = obj.sub(10, 5);

		assertEquals("Testing 10 and 5", 5, n);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testdiv() {
		
		int n = obj.divide(20, 0);

		// assertEquals("Testing 10 and 5",2,n);
	}

}
